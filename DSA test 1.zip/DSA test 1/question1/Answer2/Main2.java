
//answer2

package test2;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Queue queueX = new Queue(5);

		Stack stk = new Stack(5);
		
		Scanner sc = new Scanner(System.in);

		char num;

		for (int i = 1; i < 6; i++) {

			System.out.print("Enter number : ");

			char c = sc.next().charAt(0);

			queueX.insert(c);
		}

		

		while (!queueX.isEmpty()) {
			
			char value = queueX.remove();
			
			if (stk.isEmpty()) {
				
				stk.push(value);
				
			} else {
				
				while (stk.isEmpty() && value > stk.peek()) {

					queueX.insert(stk.pop());

				}

				stk.push(value);
			}
		}

		while (!stk.isEmpty()) {

			queueX.insert(stk.pop());

		}

		System.out.print("Integers in descending order: ");

		while (!queueX.isEmpty()) {

			System.out.print(queueX.remove() + " ");

		}

	}

}
